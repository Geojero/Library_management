CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    available BOOLEAN DEFAULT 1
);
INSERT INTO books (title) VALUES
('The Great Gatsby'),
('To Kill a Mockingbird'),
('1984'),
('Pride and Prejudice'),
('The Catcher in the Rye'),
('The Lord of the Rings'),
('The Hobbit'),
('Harry Potter and the Sorcerer''s Stone'),
('The Da Vinci Code'),
('The Chronicles of Narnia: The Lion, the Witch and the Wardrobe');
