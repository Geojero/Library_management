CREATE TABLE borrowers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    book_id INT,
    due_date DATETIME,
    returned BOOLEAN DEFAULT 0
);
