<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management</title>
    <style>
          .action-container1 {
            display: none;
            justify-content: center;
            margin:  auto;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2); /* Increased shadow */
      
        }
        .action-button {
            margin-right: 20px;
        }
            .action-button {
            width: 100%;
            background-color: green; /* Set button background color to green */
            color: white; /* Set text color to white */
            padding: 10px 20px; /* Add padding */
            border: none; /* Remove default border */
            border-radius: 5px; /* Add border radius */
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: background-color 0.3s; /* Add transition effect */
        }

        .action-button:hover {
            background-color: darkgreen; /* Change background color on hover */
        }

     
    </style>
</head>
<body>
    <header>
        <a href="https://www.jacsicoe.in/"><img src="logo.jpg"></a>
    </header>

    <?php
    $host = 'localhost';
    $dbname = 'library';
    $username = 'root';
    $password = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST["book"]) && isset($_POST["name"]) && isset($_POST["phone"]) && isset($_POST["country_code"])) {
            $bookId = $_POST["book"];
            $name = $_POST["name"];
            $phone = $_POST["country_code"] . $_POST["phone"];
            
            try {
                $sql = "UPDATE books SET available = 0 WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$bookId]);

                $sql = "INSERT INTO borrowers (book_id, name, phone) VALUES (?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$bookId, $name, $phone]);

                $mess= "Book borrowed successfully.";
                echo "<script type='text/javascript'>alert('$mess');</script>";
            } catch (PDOException $e) {
                $messi = "Error: " . $e->getMessage();
                echo "<script type='text/javascript'>alert('$messi');</script>";
            }
        }
    }
    ?>

    <div class="container">
        <div> <center>
            <table>
               
                <tr>
                
                    <td><button class="action-button" onclick="toggleForm('borrowForm')">Borrow Book</button></td>
                </tr>

            </table>
            </center>
        </div>

        <div class="action-container1" id="borrowForm">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="book">Select a Book:</label>
                <select name="book" id="book">
                    <?php
                    $result = $pdo->query("SELECT * FROM books WHERE available = 1");

                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$row['id']}'>{$row['title']}</option>";
                    }
                    ?>
                </select>

                <label for="name">Your Name:</label>
                <input type="text" name="name" id="name" required>

                <label for="phone">Your Phone Number:</label>
                <input type="text" name="country_code" id="country_code" value="+91" required pattern="\+[0-9]{1,3}">
                <input type="text" name="phone" id="phone" required pattern="[0-9]{10}"><br>

                <input type="submit" value="Borrow Book">
            </form>
        </div>

        <!-- Other forms and containers -->

    </div>

    <script>
        function toggleForm(formId) {
            var form = document.getElementById(formId);
            var containers = document.getElementsByClassName('action-container1');
            for (var i = 0; i < containers.length; i++) {
                if (containers[i].id !== formId) {
                    containers[i].style.display = "none";
                }
            }
            if (form.style.display === "none") {
                form.style.display = "block";
            } else {
                form.style.display = "none";
            }
        }
          </script>

</body>
</html>
