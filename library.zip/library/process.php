<?php
require_once 'C:\xampp\htdocs\jee\twilio-php-main\twilio-php-main\src\Twilio\autoload.php'; // Twilio PHP SDK

// Your Twilio credentials
$accountSid = "ACbc8fd74d73a478496c2f7692e280922b";
$authToken  = "501c33061c10457f69856b5d04e37cf6";
$twilioNumber = "+15169798465";

// Create a Twilio client
$client = new Twilio\Rest\Client($accountSid, $authToken);

// Establish database connection
$conn = new mysqli("localhost", "root", "", "library");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->query("SET time_zone = '+05:30'");

// Fetch form data
$book_id = $_POST['book'];
$name = $_POST['name'];
$country_code = $_POST['country_code']; // Add this line
$phone = $_POST['phone']; // Add this line

// Concatenate country code and phone number
$full_phone = $country_code . $phone;

// Set the time zone
date_default_timezone_set('Asia/Kolkata'); // Replace 'Your_Time_Zone' with your desired time zone

// Set due date to 10 minutes from now
$due_date = date('Y-m-d H:i:s', strtotime('+10 minutes'));

// Update book availability
$conn->query("UPDATE books SET available = 0 WHERE id = $book_id");

// Insert borrower information
$conn->query("INSERT INTO borrowers (name, phone, book_id, due_date) VALUES ('$name', '$full_phone', $book_id, '$due_date')");

$conn->close();


// Redirect to index.php after processing
header("Location: index.php");
exit();
?>
