<?php
$host = 'localhost';
$dbname = 'library';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$connection = mysqli_connect($host, $username, $password, $dbname);

// Check if the connection was successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$flag = 0; // Variable to track if the user is valid

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from the form
    $username1 = $_POST['username'];
    $password1 = $_POST['password'];

    // Query the database to check if the username and password combination exists
    $query = "SELECT * FROM students WHERE username='$username1' AND password='$password1'";
    $result = mysqli_query($connection, $query);

    // Check if there is a match
    if (mysqli_num_rows($result) == 1) {
        // Username and password match found
        $flag = 1; // Set flag to indicate valid user
        $mes = "Login successful!";
        echo "<script type='text/javascript'>alert('$mes');</script>";
    } else {
        // No match found
        $invalid = "Invalid username or password.";
        echo "<script type='text/javascript'>alert('$invalid');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management</title>
    <style>
        .action-container {
            justify-content: center;
            display: flex;
            justify-content: center;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }

        .action-button {
            background-color: green;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .action-button:hover {
            background-color: darkgreen;
        }
    </style>
</head>
<body>
<header>
    <a href="https://www.jacsicoe.in/"><img src="logo.jpg" alt="Library Logo"></a>
</header>

<?php
// Display borrowing section only if the user is valid
if ($flag == 1) {
    header("Location: borrow.php");
    exit;

}



 else {
    // Redirect the user back to the login page
    header("Location: index.html");
    exit;
}
?>

</body>
</html>
