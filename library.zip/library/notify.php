<!DOCTYPE html>
<html>
<head>
    <!-- <meta http-equiv="refresh" content="5;url=index.php"> -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Notification</title>
</head>
<body>
<?php
require_once 'C:\xampp\htdocs\jee\twilio-php-main\twilio-php-main\src\Twilio\autoload.php'; // Twilio PHP SDK

// Your Twilio credentials
$accountSid = "ACbc8fd74d73a478496c2f7692e280922b";
$authToken  = "501c33061c10457f69856b5d04e37cf6";
$twilioNumber = "+15169798465";

// Create a Twilio client
$client = new Twilio\Rest\Client($accountSid, $authToken);

$conn = new mysqli("localhost", "root", "", "library");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch borrowers with due date reached
$result = $conn->query("SELECT * FROM borrowers WHERE due_date <= NOW() AND returned = 0");

while ($row = $result->fetch_assoc()) {
    // Replace with actual SMS sending logic using Twilio
    $message = "Dear {$row['name']}, the due date for '{$row['book_id']}' has been reached. Please return the book.";

    // Example: Send SMS using Twilio
    $client->messages->create(
        $row['phone'], // recipient's phone number
        ['from' => $twilioNumber, 'body' => $message]
    );
}

$conn->close();
?>

</body>
</html>