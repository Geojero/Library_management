<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management</title>
    <style>
          .action-container11 {
            display: none;
            justify-content: center;
            margin:  auto;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2); /* Increased shadow */
      
        }
        .action-button {
            margin-right: 20px;
        }
            .action-button {
            background-color: green; /* Set button background color to green */
            color: white; /* Set text color to white */
            padding: 10px 20px; /* Add padding */
            border: none; /* Remove default border */
            border-radius: 5px; /* Add border radius */
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: background-color 0.3s; /* Add transition effect */
        }

        .action-button:hover {
            background-color: darkgreen; /* Change background color on hover */
        }

     
    </style>
</head>
<body>
    <header>
        <a href="https://www.jacsicoe.in/"><img src="logo.jpg"></a>
    </header>

    <?php
    $host = 'localhost';
    $dbname = 'library';
    $username = 'root';
    $password = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }

    // Function to borrow book
    function registeration($pdo) {
       $host = 'localhost';
$dbname = 'library';
$username = 'root';
$password = '';

// Establish a database connection
$connection = mysqli_connect($host, $username, $password, $dbname);

// Check if the form is submitted
if (isset($_POST["username"]) && isset($_POST["password"])) {
    //
    // Retrieve username and password from the form
    $username123 = $_POST['username'];
    $password123= $_POST['password'];

    // Hash the password for security
 

    // Query to insert the username and hashed password into the database
    $query = "INSERT INTO students (username, password) VALUES ('$username123', '$password123')";

    // Execute the query
    if (mysqli_query($connection, $query)) {
        // Insert successful
        $mess1= "User registered successfully!";
        echo "<script type='text/javascript'>alert('$mess1');</script>";
        // Redirect to a success page or do further actions
    } else {
        // Insert failed
        $mess2 = "Error: " . mysqli_error($connection);
        

        // You may redirect back to the registration page with an error message
    }
}

// Close
mysqli_close($connection);
    }





    function borrowBook($pdo) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST["book"]) && isset($_POST["name"]) && isset($_POST["phone"]) && isset($_POST["country_code"])) {
                $bookId = $_POST["book"];
                $name = $_POST["name"];
                $phone = $_POST["country_code"] . $_POST["phone"];
                
                try {
                    // Update book availability
                    $sql = "UPDATE books SET available = 0 WHERE id = ?";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$bookId]);

                    // Insert borrower information
                    $sql = "INSERT INTO borrowers (book_id, name, phone) VALUES (?, ?, ?)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$bookId, $name, $phone]);

                    $mess= "Book borrowed successfully.";
                    echo "<script type='text/javascript'>alert('$mess');</script>";
                } catch (PDOException $e) {
                    $messi = "Error: " . $e->getMessage();
                    echo "<script type='text/javascript'>alert('$messi');</script>";
                }
            }
        }
    }

    function updateBookTitle($pdo) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST["title"]) && isset($_POST["book_id"])) {
            $title = $_POST["title"];
            $bookId = $_POST["book_id"];
            
            try {
                // Check if the book exists
                $sql = "SELECT * FROM books WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$bookId]);
                $existingBook = $stmt->fetch();
                
                if ($existingBook) {
                    // If the book exists, update its title
                    $sql = "UPDATE books SET title = ? WHERE id = ?";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$title, $bookId]);
                    echo "Title updated successfully.";
                } else {
                    // If the book doesn't exist, insert a new record
                    $sql = "INSERT INTO books (id, title, available) VALUES (?, ?, 1)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$bookId, $title]);
                    echo "Book inserted successfully.";
                }
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
            }
        }
    }
    }

// Function to change availability
function changeAvailability($pdo) {
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["changeavailable"])) {
        $available = $_POST["available"];
        $title = $_POST["selected_title"];

        try {
            $sql = "UPDATE books SET available = ? WHERE title = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$available, $title]);
            
            echo "Availability updated successfully.";
        } catch (PDOException $e) {
            echo "Error updating availability: " . $e->getMessage();
        }
    }
}

// Function to update returned value
function updateReturnedValue($pdo) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['name'])) {
            $borrower_id = $_POST['name'];
            $returned_value = isset($_POST['returned']) ? 1 : 0;

            $sql = "UPDATE borrowers SET returned=? WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$returned_value, $borrower_id]);

            echo "Returned value updated successfully.";
        }
    }
}

    // Calling function
    borrowBook($pdo);
    updateBookTitle($pdo);
changeAvailability($pdo);
updateReturnedValue($pdo);
registeration($pdo);
    ?>

    <div class="container">
        <div> <center>
            <table>
               
                <tr>
                    <td><button class="action-button" onclick="toggleForm('updateBookTitleForm')">ADD New Book</button><br></td>
                    <td><button class="action-button" onclick="toggleForm('changeAvailabilityForm')">Change Availability</button><br></td>
                    <td><button class="action-button" onclick="toggleForm('updateReturnedValueForm')">Update Returned Value</button></td>
                    <td><button class="action-button" onclick="toggleForm('borrowForm')">Borrow Book</button></td>
                    <td><button class="action-button" onclick="toggleForm('registeration')">New User</button></td>
                    <td><button  class="action-button" onclick="redirectToNotify()">Notify</button></td>
                </tr>

            </table>
            </center>
        </div>

        <div class="action-container1" id="borrowForm">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="book">Select a Book:</label>
                <select name="book" id="book">
                    <?php
                    $result = $pdo->query("SELECT * FROM books WHERE available = 1");

                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$row['id']}'>{$row['title']}</option>";
                    }
                    ?>
                </select>

                <label for="name">Your Name:</label>
                <input type="text" name="name" id="name" required>

                <label for="phone">Your Phone Number:</label>
                <input type="text" name="country_code" id="country_code" value="+91" required pattern="\+[0-9]{1,3}">
                <input type="text" name="phone" id="phone" required pattern="[0-9]{10}"><br>

                <input type="submit" value="Borrow Book">
            </form>
        </div>









        <div class="action-container1" id="registeration">
    <h2>User Registration</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>
        
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        
        <input type="submit" value="Register">
    </form>
</div>
        <!-- Action forms for update book title, change availability, and update returned value -->

    
      <div class="action-container1" id="updateBookTitleForm">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="book_id">Book ID:</label>
              <input type="text" id="book_id" name="book_id" required>
                    <br><br>
                <label for="title">New Title:</label>
                <input type="text" id="title" name="title" required>
                <br><br>
                <input type="submit" value="Update Title">
            </form>
        </div>

    <div class="action-container1" id="changeAvailabilityForm">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="selected_title">Title:</label>
            <select id="selected_title" name="selected_title" required>
                <?php
                $sql = "SELECT title FROM books";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                $titles = $stmt->fetchAll(PDO::FETCH_COLUMN);
                foreach ($titles as $title) {
                    echo "<option value='$title'>$title</option>";
                }
                ?>
            </select>
            <br><br>
            <label for="available">Availability:</label>
            <select id="available" name="available" required>
                <option value="1">Available</option>
                <option value="0">Unavailable</option>
            </select>
            <br><br>
            <input type="submit" name="changeavailable" value="Change Availability">
        </form>
    </div>

    <div class="action-container1" id="updateReturnedValueForm">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <label for="name">Select Borrower Name:</label>
            <select name="name" id="name">
                <?php
                $sql = "SELECT id, name FROM borrowers WHERE returned = 0";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                $borrowers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($borrowers as $borrower) {
                    echo "<option value='" . $borrower['id'] . "'>" . $borrower['name'] . "</option>";
                }
                ?>
            </select>
            <br><br>
            <label for="returned">Returned:</label>
            <input type="checkbox" name="returned" value="1">
            <br><br>
            <input type="submit" value="Update">
        </form>
    </div>
</div>
    <script>
        function toggleForm(formId) {
            var form = document.getElementById(formId);
            var containers = document.getElementsByClassName('action-container1');
            for (var i = 0; i < containers.length; i++) {
                if (containers[i].id !== formId) {
                    containers[i].style.display = "none";
                }
            }
            if (form.style.display === "none") {
                form.style.display = "block";
            } else {
                form.style.display = "none";
            }
        }

        function redirectToNotify() {
            window.location.href = 'http://localhost/jee/notify.php';
        }
    </script>

</body>
</html>
